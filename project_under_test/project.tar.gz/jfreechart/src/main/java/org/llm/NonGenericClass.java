package org.llm;

public class NonGenericClass {
    public GenericContainer<String> createContainer(String value) {
        if (value == null) {
            throw new IllegalArgumentException("Value cannot be null");
        }

        if (value.isEmpty()) {
            return new GenericContainer<>("Default Value");
        }

        if (value.length() > 10) {
            return new GenericContainer<>("Too Long");
        }

        return new GenericContainer<>(value);
    }
}