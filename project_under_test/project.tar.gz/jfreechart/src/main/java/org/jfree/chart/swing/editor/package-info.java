/**
 * Provides a simple (but so far incomplete) framework for editing chart properties.
 */
package org.jfree.chart.swing.editor;
