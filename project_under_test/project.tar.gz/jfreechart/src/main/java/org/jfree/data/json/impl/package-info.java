/**
 * Utility classes for JSON, for internal use only.
 */
package org.jfree.data.json.impl;
