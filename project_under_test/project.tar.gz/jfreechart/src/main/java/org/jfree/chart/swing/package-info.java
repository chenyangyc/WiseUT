/**
 * Classes that provide support for JFreeChart in Swing applications.
 */
package org.jfree.chart.swing;
