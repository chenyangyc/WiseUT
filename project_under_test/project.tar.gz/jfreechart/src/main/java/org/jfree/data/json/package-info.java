/**
 * Utilities for reading/writing data to/from JSON format.
 */
package org.jfree.data.json;
